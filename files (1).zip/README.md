# Colorful Dino Runner

A colorful, self-contained clone of the Chrome dinosaur game — built with HTML5 canvas, vanilla JavaScript and CSS.

Features
- Colorful obstacles and background gradients
- Jump and duck controls (Space/Arrow Up to jump, Arrow Down to duck)
- Tap to jump on touch devices
- Score and persistent high-score (localStorage)
- Easy to run locally (open `index.html`)

How to run
1. Open `index.html` in a modern browser, or:
2. Serve the folder with a simple HTTP server:
   - Python 3: `python -m http.server 8000`
   - then open `http://localhost:8000`

Controls
- Windows / Mac: Space or ↑ to jump, ↓ to duck. Press Start / Restart to restart.
- Mobile: Tap canvas to jump.

Files
- `index.html` — main page
- `css/style.css` — styles
- `js/game.js` — gameplay code
- `LICENSE` — MIT license

License
MIT